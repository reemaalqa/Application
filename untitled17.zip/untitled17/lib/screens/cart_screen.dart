import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Stack(
          children: <Widget>[
            // الصورة الأولى
            Container(
              width: MediaQuery.of(context).size.width, // عرض الشاشة
              height: 100, // ارتفاع محدد
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/rectangle149.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            // الصورة الثانية
            Positioned(
              bottom: 0, // في الجزء السفلي من الشاشة
              left: 300, // في الجانب الأيسر من الشاشة
              child: Container(
                width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('images/ellipse58.png'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            // الصورة الثالثة
            Positioned(
              top: 0, // في الجزء العلوي من الشاشة
              right: 300, // في الجانب الأيمن من الشاشة
              child: Container(
                width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('images/ellipse59.png'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                40.heightBox,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white,
                    ),
                    Text("My Cart",
                        style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w600,
                            color: Colors.white)),
                    Image.asset('images/k.png', width: 49, height: 49),
                  ],
                ),
              ],
            ),
          ],
        ),
        10.heightBox,
        Container(
          width: 366,
          height: 100,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 6,
                offset: Offset(0, 4),
                spreadRadius: 0,
              )
            ],
          ),
          child: Row(
            children: [
              10.widthBox,
              Container(
                width: 88,
                height: 82,
                decoration: ShapeDecoration(
                  image: DecorationImage(
                    image: AssetImage("images/z.png"),
                    fit: BoxFit.fill,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              10.widthBox,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  10.heightBox,
                  Text(
                    'Listrik statis dan dinamis',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    'with Mrs Devi',
                    style: TextStyle(
                      color: Color(0xFF8812FF),
                      fontSize: 10,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    '17 hours / 62 lessons',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 13,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                  Text(
                    'Rp 230.000',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        10.heightBox,
        Container(
          width: 366,
          height: 100,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 6,
                offset: Offset(0, 4),
                spreadRadius: 0,
              )
            ],
          ),
          child: Row(
            children: [
              10.widthBox,
              Container(
                width: 88,
                height: 82,
                decoration: ShapeDecoration(
                  image: DecorationImage(
                    image: AssetImage("images/z.png"),
                    fit: BoxFit.fill,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              10.widthBox,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  10.heightBox,
                  Text(
                    'Listrik statis dan dinamis',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    'with Mrs Devi',
                    style: TextStyle(
                      color: Color(0xFF8812FF),
                      fontSize: 10,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    '17 hours / 62 lessons',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 13,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                  Text(
                    'Rp 230.000',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        10.heightBox,
        Container(
          width: 366,
          height: 100,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 6,
                offset: Offset(0, 4),
                spreadRadius: 0,
              )
            ],
          ),
          child: Row(
            children: [
              10.widthBox,
              Container(
                width: 88,
                height: 82,
                decoration: ShapeDecoration(
                  image: DecorationImage(
                    image: AssetImage("images/z.png"),
                    fit: BoxFit.fill,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              10.widthBox,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  10.heightBox,
                  Text(
                    'Listrik statis dan dinamis',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    'with Mrs Devi',
                    style: TextStyle(
                      color: Color(0xFF8812FF),
                      fontSize: 10,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                  Text(
                    '17 hours / 62 lessons',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 13,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                  Text(
                    'Rp 230.000',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontFamily: 'Nunito',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        20.heightBox,
        Container(
          width: 367,
          height: 150,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Color(0xFF8812FF),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 8,
                offset: Offset(0, 3),
                spreadRadius: 0,
              )
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 105,
                child: Container(
                  width: 368,
                  height: 50,
                  decoration: BoxDecoration(color: Color(0xFF5A8A88)),
                ),
              ),
              Positioned(
                left: 15,
                top: 13,
                child: Text(
                  'Sub total :',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 15,
                top: 43,
                child: Text(
                  'Discount :',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 15,
                top: 73,
                child: Text(
                  'Promocode :',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 15,
                top: 112,
                child: Text(
                  'Total :',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 259,
                top: 13,
                child: Text(
                  'Rp 930.000',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 259,
                top: 112,
                child: Text(
                  'Rp 790.500',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 319,
                top: 43,
                child: Text(
                  '15%',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 319,
                top: 73,
                child: Text(
                  '----',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
            ],
          ),
        ),
        10.heightBox,
        Container(
          width: 367,
          height: 38,
          padding: const EdgeInsets.only(
            top: 6,
            left: 131,
            right: 127,
            bottom: 7,
          ),
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Color(0xFFFFBA00),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 4,
                offset: Offset(0, 4),
                spreadRadius: 0,
              )
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Purchase All',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontFamily: 'Nunito',
                  fontWeight: FontWeight.w800,
                  height: 0,
                ),
              ),
            ],
          ),
        )
      ]),
    );
  }
}
