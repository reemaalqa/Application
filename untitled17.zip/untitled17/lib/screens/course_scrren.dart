import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class CuorseScreen extends StatelessWidget {
  const CuorseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            physics: const BouncingScrollPhysics(),
            child: Column(children: [
              Stack(
                children: <Widget>[
                  // الصورة الأولى
                  Container(
                    width: MediaQuery.of(context).size.width, // عرض الشاشة
                    height: 100, // ارتفاع محدد
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('images/rectangle149.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  // الصورة الثانية
                  Positioned(
                    bottom: 0, // في الجزء السفلي من الشاشة
                    left: 300, // في الجانب الأيسر من الشاشة
                    child: Container(
                      width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/ellipse58.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  // الصورة الثالثة
                  Positioned(
                    top: 0, // في الجزء العلوي من الشاشة
                    right: 300, // في الجانب الأيمن من الشاشة
                    child: Container(
                      width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/ellipse59.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      40.heightBox,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                          ),
                          Text("Course",
                              style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white)),
                          Image.asset('images/k.png', width: 49, height: 49),
                        ],
                      )
                    ],
                  ),
                ],
              ),
              10.heightBox,
              Row(
                children: <Widget>[
                  30.widthBox,
                  Text("All Course",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      )),
                  20.widthBox,
                  Text("My Course",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      )),
                  20.widthBox,
                  Text("Download",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      )),
                  20.widthBox,
                  Text("E-Book",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      )),
                ],
              ),
              20.heightBox,
              Container(
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.centerLeft,
                child: Text("My Course",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    )),
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '     Academic',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 14,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                  Text(
                    'See All     ',
                    style: TextStyle(
                      color: Color(0xFF4E7B79),
                      fontSize: 14,
                      fontFamily: 'Montserrat    ',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                ],
              ),
              10.heightBox,
              Container(
                width: MediaQuery.of(context).size.width - 50,
                child: Divider(
                  height: 10,
                  color: Color(0xff7D7D7D),
                ),
              ),
              10.heightBox,
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    30.widthBox,
                    Container(
                      width: 286,
                      height: 233,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        shadows: [
                          BoxShadow(
                            color: Color(0x3F000000),
                            blurRadius: 8,
                            offset: Offset(4, 7),
                            spreadRadius: 0,
                          )
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("images/rectangle177.png"),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration:
                                  BoxDecoration(color: Color(0x59626262)),
                            ),
                          ),
                          Positioned(
                            left: 39,
                            top: 108,
                            child: Container(
                              width: 212,
                              height: 5,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 212,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 118,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Color(0xFFFFAD02),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 107,
                            top: 32.50,
                            child: Container(
                              width: 57,
                              height: 57.90,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      left: 0,
                                      top: 0,
                                      child: Container(
                                        width: 57,
                                        height: 57.90,
                                        child: Image.asset('images/kkk.png'),
                                      )),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 162,
                            child: SizedBox(
                              width: 266,
                              height: 37,
                              child: Text(
                                'Hukum Bernoulli merupakan sebuah hukum yang menjelaskan besar kecilnya tekanan dari fluida yang bergerak seperti halnya udara, dan akan berkurang ketika fluida tersebut bergerak lebih cepat.\n',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 211,
                            child: SizedBox(
                              width: 37,
                              height: 11,
                              child: Text(
                                'Eps 7/25',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 125,
                            child: Text(
                              'Fisika SMA IPA Hukum Bernoulli ',
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 87,
                            top: 144,
                            child: Text(
                              '(2,103)',
                              style: TextStyle(
                                color: Color(0xFF6A6A6A),
                                fontSize: 10,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 181,
                            top: 204,
                            child: Container(
                              width: 97,
                              height: 21,
                              decoration: ShapeDecoration(
                                color: Color(0xFFFFBA00),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5)),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 205,
                            top: 206,
                            child: Text(
                              'Continue',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    30.widthBox,
                    Container(
                      width: 286,
                      height: 233,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        shadows: [
                          BoxShadow(
                            color: Color(0x3F000000),
                            blurRadius: 8,
                            offset: Offset(4, 7),
                            spreadRadius: 0,
                          )
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("images/rectangle177.png"),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration:
                                  BoxDecoration(color: Color(0x59626262)),
                            ),
                          ),
                          Positioned(
                            left: 39,
                            top: 108,
                            child: Container(
                              width: 212,
                              height: 5,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 212,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 118,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Color(0xFFFFAD02),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 107,
                            top: 32.50,
                            child: Container(
                              width: 57,
                              height: 57.90,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      left: 0,
                                      top: 0,
                                      child: Container(
                                        width: 57,
                                        height: 57.90,
                                        child: Image.asset('images/kkk.png'),
                                      )),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 162,
                            child: SizedBox(
                              width: 266,
                              height: 37,
                              child: Text(
                                'Hukum Bernoulli merupakan sebuah hukum yang menjelaskan besar kecilnya tekanan dari fluida yang bergerak seperti halnya udara, dan akan berkurang ketika fluida tersebut bergerak lebih cepat.\n',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 211,
                            child: SizedBox(
                              width: 37,
                              height: 11,
                              child: Text(
                                'Eps 7/25',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 125,
                            child: Text(
                              'Fisika SMA IPA Hukum Bernoulli ',
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 87,
                            top: 144,
                            child: Text(
                              '(2,103)',
                              style: TextStyle(
                                color: Color(0xFF6A6A6A),
                                fontSize: 10,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 181,
                            top: 204,
                            child: Container(
                              width: 97,
                              height: 21,
                              decoration: ShapeDecoration(
                                color: Color(0xFFFFBA00),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5)),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 205,
                            top: 206,
                            child: Text(
                              'Continue',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              20.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '     Academic',
                    style: TextStyle(
                      color: Color(0xFF444444),
                      fontSize: 14,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                  Text(
                    'See All     ',
                    style: TextStyle(
                      color: Color(0xFF4E7B79),
                      fontSize: 14,
                      fontFamily: 'Montserrat    ',
                      fontWeight: FontWeight.w600,
                      height: 0,
                    ),
                  ),
                ],
              ),
              10.heightBox,
              Container(
                width: MediaQuery.of(context).size.width - 50,
                child: Divider(
                  height: 10,
                  color: Color(0xff7D7D7D),
                ),
              ),
              10.heightBox,
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    30.widthBox,
                    Container(
                      width: 286,
                      height: 233,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        shadows: [
                          BoxShadow(
                            color: Color(0x3F000000),
                            blurRadius: 8,
                            offset: Offset(4, 7),
                            spreadRadius: 0,
                          )
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("images/rectangle177.png"),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration:
                                  BoxDecoration(color: Color(0x59626262)),
                            ),
                          ),
                          Positioned(
                            left: 39,
                            top: 108,
                            child: Container(
                              width: 212,
                              height: 5,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 212,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 118,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Color(0xFFFFAD02),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 107,
                            top: 32.50,
                            child: Container(
                              width: 57,
                              height: 57.90,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      left: 0,
                                      top: 0,
                                      child: Container(
                                        width: 57,
                                        height: 57.90,
                                        child: Image.asset('images/kkk.png'),
                                      )),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 162,
                            child: SizedBox(
                              width: 266,
                              height: 37,
                              child: Text(
                                'Hukum Bernoulli merupakan sebuah hukum yang menjelaskan besar kecilnya tekanan dari fluida yang bergerak seperti halnya udara, dan akan berkurang ketika fluida tersebut bergerak lebih cepat.\n',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 211,
                            child: SizedBox(
                              width: 37,
                              height: 11,
                              child: Text(
                                'Eps 7/25',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 125,
                            child: Text(
                              'Fisika SMA IPA Hukum Bernoulli ',
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 87,
                            top: 144,
                            child: Text(
                              '(2,103)',
                              style: TextStyle(
                                color: Color(0xFF6A6A6A),
                                fontSize: 10,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 181,
                            top: 204,
                            child: Container(
                              width: 97,
                              height: 21,
                              decoration: ShapeDecoration(
                                color: Color(0xFFFFBA00),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5)),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 205,
                            top: 206,
                            child: Text(
                              'Continue',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    30.widthBox,
                    Container(
                      width: 286,
                      height: 233,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        shadows: [
                          BoxShadow(
                            color: Color(0x3F000000),
                            blurRadius: 8,
                            offset: Offset(4, 7),
                            spreadRadius: 0,
                          )
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("images/rectangle177.png"),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 286,
                              height: 120,
                              decoration:
                                  BoxDecoration(color: Color(0x59626262)),
                            ),
                          ),
                          Positioned(
                            left: 39,
                            top: 108,
                            child: Container(
                              width: 212,
                              height: 5,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 212,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    child: Container(
                                      width: 118,
                                      height: 5,
                                      decoration: ShapeDecoration(
                                        color: Color(0xFFFFAD02),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 107,
                            top: 32.50,
                            child: Container(
                              width: 57,
                              height: 57.90,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 4.75,
                                    top: 4.82,
                                    child: Container(
                                      width: 47.50,
                                      height: 48.25,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                              "https://via.placeholder.com/47x48"),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      left: 0,
                                      top: 0,
                                      child: Container(
                                        width: 57,
                                        height: 57.90,
                                        child: Image.asset('images/kkk.png'),
                                      )),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 162,
                            child: SizedBox(
                              width: 266,
                              height: 37,
                              child: Text(
                                'Hukum Bernoulli merupakan sebuah hukum yang menjelaskan besar kecilnya tekanan dari fluida yang bergerak seperti halnya udara, dan akan berkurang ketika fluida tersebut bergerak lebih cepat.\n',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 211,
                            child: SizedBox(
                              width: 37,
                              height: 11,
                              child: Text(
                                'Eps 7/25',
                                style: TextStyle(
                                  color: Color(0xFF8C8C8C),
                                  fontSize: 8,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 125,
                            child: Text(
                              'Fisika SMA IPA Hukum Bernoulli ',
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 87,
                            top: 144,
                            child: Text(
                              '(2,103)',
                              style: TextStyle(
                                color: Color(0xFF6A6A6A),
                                fontSize: 10,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 181,
                            top: 204,
                            child: Container(
                              width: 97,
                              height: 21,
                              decoration: ShapeDecoration(
                                color: Color(0xFFFFBA00),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5)),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 205,
                            top: 206,
                            child: Text(
                              'Continue',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600,
                                height: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ])));
  }
}
