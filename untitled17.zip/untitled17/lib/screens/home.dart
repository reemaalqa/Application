import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:untitled17/screens/cart_screen.dart';
import 'package:untitled17/screens/profile_screen.dart';

import 'course_scrren.dart';
import 'home_screen.dart';
import 'login_screen.dart';

var indexProvider = StateProvider<int>((ref) => 0);

class Home extends ConsumerWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pageController = PageController();
    var index = ref.watch(indexProvider);

    var navbarItem = [
      BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
            size: 26,
          ),
          label: 'Home'),
      BottomNavigationBarItem(
          icon: Image.asset('images/i2.png', width: 26), label: 'Course'),
      BottomNavigationBarItem(
          icon: Image.asset('images/i3.png', width: 26), label: 'Cart'),
      BottomNavigationBarItem(
          icon: Image.asset('images/i4.png', width: 26), label: 'Profile'),
    ];
    return Scaffold(
      body: PageView(controller: pageController, children: [
        HomeScreen(),
        CuorseScreen(),
        CartScreen(),
        ProfileScreen(),
      ]),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          ref.read(indexProvider.notifier).state = index;
          pageController.animateToPage(
            index,
            duration: Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          );
          print(pageController);
        },
        items: navbarItem,
        currentIndex: ref.watch(indexProvider),
        selectedItemColor: Colors.purpleAccent,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.w400),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
      ),
    );
  }
}
