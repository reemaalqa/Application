import 'package:flutter/material.dart';
import 'package:untitled17/screens/login_screen.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';


class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {


    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              Stack(
                children: <Widget>[
                  // الصورة الأولى
                  Container(
                    width: MediaQuery.of(context).size.width, // عرض الشاشة
                    height: 165, // ارتفاع محدد
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('images/rectangle149.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  // الصورة الثانية
                  Positioned(
                    bottom: 0, // في الجزء السفلي من الشاشة
                    left: 300, // في الجانب الأيسر من الشاشة
                    child: Container(
                      width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/ellipse58.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  // الصورة الثالثة
                  Positioned(
                    top: 0, // في الجزء العلوي من الشاشة
                    right: 300, // في الجانب الأيمن من الشاشة
                    child: Container(
                      width: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      height: 100.0, // يمكنك تغيير هذا لتحديد حجم الصورة
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/ellipse59.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      20.heightBox,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset('images/group1741.png',width: 49,height: 49),
                          Text(
                              "LEARNING DESK",
                              style: TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w600,color: Colors.white
                              )
                          ),
                          Image.asset('images/k.png',width: 49,height: 49),
                        ],
                      ),
                      20.heightBox,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // حقل الإدخال مع أيقونة البحث
                          Container(
                            width: 311,
                            height: 50,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(6.0),
                        bottomLeft: Radius.circular(6.0),
                      ), // يمكنك تغيير هذا لتحديد مدى تقريب الحدود
                              color: Colors.white,
                            ),
                            child: TextField(
                              decoration: InputDecoration(
                                hintText: '   Search', // هذا هو النص
                                suffixIcon: Icon(Icons.search), // هذه هي أيقونة البحث
                                border: InputBorder.none, // هذا يزيل الحدود الافتراضية لحقل الإدخال
                              ),
                            ),
                          ),
                          // الحاوية مع أيقونة الإعدادات
                          Container(
                            width: 57,
                            height: 50,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(6.0),
                                bottomRight: Radius.circular(6.0),
                              ), // يمكنك تغيير هذا لتحديد مدى تقريب الحدود
                              color: Color(0xfff7ba34),
                            ),
                            child:Image.asset('images/h.png',width: 49,height: 49), // هذه هي أيقونة الإعدادات
                          ),
                        ],
                      ),

                    ],
                  )
                ],
              ),
              20.heightBox,
              Column(
                children: [


              Container(

                width: 367,
                height: 122,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      top: 0,
                      child: Container(
                        width: 367,
                        height: 122,
                        decoration: ShapeDecoration(
                          color: Colors.white,
                          shadows: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3), // changes position of shadow
                            ),
                          ],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        )
,
                      ),
                    ),
                    Positioned(
                      left: 103,
                      top: 20,
                      child: Text(
                        'John Doe ',
                        style: TextStyle(
                          color: Color(0xFF444444),
                          fontSize: 28,
                          fontFamily: 'Nunito',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 22,
                      top: 14,
                      child: Container(
                        width: 63,
                        height: 68,
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              top: 0,
                              child: Container(
                                width: 63,
                                height: 63,
                                decoration: ShapeDecoration(
                                  image: DecorationImage(
                                    image: AssetImage("images/ellipse56.png"),
                                    fit: BoxFit.fill,
                                  ),
                                  shape: OvalBorder(
                                    side: BorderSide(
                                      width: 2,
                                      strokeAlign: BorderSide.strokeAlignOutside,
                                      color: Color(0xFF4E7B79),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 0,
                              top: 53,
                              child: Container(
                                width: 63,
                                height: 15,
                                decoration: ShapeDecoration(
                                  color: Color(0xFFF7BA34),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2)),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 12,
                              top: 54,
                              child: Text(
                                'Level 10',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontFamily: 'Montserrat',
                                  fontWeight: FontWeight.w500,
                                  height: 0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 297,
                      top: 14,
                      child: Text(
                        'See Detail',
                        style: TextStyle(
                          color: Color(0xFF4E7B79),
                          fontSize: 10,
                          fontFamily: 'Montserrat',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 103,
                      top: 70,
                      child: Text(
                        '240 XP',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 10,
                          fontFamily: 'Montserrat',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 164,
                      top: 70,
                      child: Text(
                        '400 Gold',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 10,
                          fontFamily: 'Montserrat',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      top: 93,
                      child: Container(
                        width: 329,
                        height: 19,
                        child: Stack(
                          children: [
                            Positioned(
                              left: 3,
                              top: 0,
                              child: Container(
                                width: 326,
                                height: 19,
                                decoration: ShapeDecoration(
                                  color: Color(0xFFEFEFEF),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 0,
                              top: 0,
                              child: Container(
                                width: 256,
                                height: 19,
                                decoration: ShapeDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment(-1.00, 0.00),
                                    end: Alignment(1, 0),
                                    colors: [Color(0xFFF7BA34), Color(0xFFF87B34)],
                                  ),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 141,
                              top: 3,
                              child: Text(
                                '83/100 XP',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontFamily: 'Montserrat',
                                  fontWeight: FontWeight.w600,
                                  height: 0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                  ],
                ),
              ),
             20.heightBox,
              Row(

                children: [
10.widthBox,
                  Text(
                      "Course Category",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      )
                  ),
170.widthBox,
                  Text(
                      "See All",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      )
                  ),
                  10.widthBox,
                ],
              ),
              10.heightBox,
              Row(
                children: [
                  20.widthBox,
                  Column(
                    children: [
                      Container(
                          width: 75,
                          height: 68,
                          decoration:     BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xffb9e3e2)),
                        child: Image.asset('images/b.png'),
                      ),
                      Text(
                          "Materi",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          )
                      ),
                    ],
                  ),
                  20.widthBox,
                  Column(
                    children: [
                      Container(
                        width: 75,
                        height: 68,
                        decoration:     BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0xfffcd4dc)),
                        child: Image.asset('images/w.png'),
                      ),
                      Text(
                          "Latihan",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          )
                      )
                    ],
                  ),
                  20.widthBox,
                  Column(
                    children: [
                      Container(
                        width: 75,
                        height: 68,
                        decoration:     BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0xffd0e2ff)),
                        child: Image.asset('images/d.png'),
                      ),
                      Text(
                          "Ujian",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          )
                      )
                    ],
                  ),
                  20.widthBox,
                  Column(
                    children: [
                      Container(
                        width: 75,
                        height: 68,
                        decoration:     BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0xffffebbf)),
                        child: Image.asset('images/l.png'),
                      ),
                      Text(
                          "Try Out",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          )
                      )
                    ],
                  ),
                ],
              ),
              20.heightBox,
              Row(

                children: [
                  10.widthBox,
                  Text(
                      "Recommended for you",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      )
                  ),
                  130.widthBox,
                  Text(
                      "See All",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      )
                  ),
                  10.widthBox,
                ],
              ),
10.heightBox,
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    30.widthBox,
                    Container(
                      width: 335,
                      height: 100,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
    shadows: [
    BoxShadow(
    color: Colors.grey.withOpacity(0.5),
    spreadRadius: 5,
    blurRadius: 7,
    offset: Offset(0, 3), // changes position of shadow
    )],
                        color: Colors.white,
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: ShapeDecoration(
                              image: DecorationImage(
                                image: AssetImage("images/rectangle177.png"),
                                fit: BoxFit.fill,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          20.widthBox,
                          Column(
                            children: [
                             5.heightBox,
                          Text(
                            'Paket 2 bulan kelas',
                            style: TextStyle(
                              color: Color(0xFF444444),
                              fontSize: 18,
                              fontFamily: 'Nunito',
                              fontWeight: FontWeight.w600,
                              height: 0,
                            ),
                          ),
                          Text(
                            '10 - 11 - 12 IPA IPS',
                            style: TextStyle(
                              color: Color(0xFF444444),
                              fontSize: 18,
                              fontFamily: 'Nunito',
                              fontWeight: FontWeight.w600,
                              height: 0,
                            ),
                          ),
                          25.heightBox,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.asset('images/group.png',width: 29,height: 28,),
                              10.widthBox,
                              Text(
                                '(4,177)',
                                style: TextStyle(
                                  color: Color(0xFF6A6A6A),
                                  fontSize: 18,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                              60.widthBox,
                              Image.asset('images/kk.png',width: 29,height: 28,),


                            ],
                          ),

                            ],
                          ),

                        ],
                      ),
                    ),
                    30.heightBox,
                    Container(
                      width: 335,
                      height: 100,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        shadows: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          )],
                        color: Colors.white,
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: ShapeDecoration(
                              image: DecorationImage(
                                image: AssetImage("images/rectangle177.png"),
                                fit: BoxFit.fill,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          20.widthBox,
                          Column(
                            children: [
                              5.heightBox,
                              Text(
                                'Paket 2 bulan kelas',
                                style: TextStyle(
                                  color: Color(0xFF444444),
                                  fontSize: 18,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w600,
                                  height: 0,
                                ),
                              ),
                              Text(
                                '10 - 11 - 12 IPA IPS',
                                style: TextStyle(
                                  color: Color(0xFF444444),
                                  fontSize: 18,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w600,
                                  height: 0,
                                ),
                              ),
                              25.heightBox,
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Image.asset('images/group.png',width: 29,height: 28,),
                                  10.widthBox,
                                  Text(
                                    '(4,177)',
                                    style: TextStyle(
                                      color: Color(0xFF6A6A6A),
                                      fontSize: 18,
                                      fontFamily: 'Nunito',
                                      fontWeight: FontWeight.w400,
                                      height: 0,
                                    ),
                                  ),
                                  60.widthBox,
                                  Image.asset('images/kk.png',width: 29,height: 28,),


                                ],
                              ),

                            ],
                          ),

                        ],
                      ),
                    ),
                    30.widthBox,
                  ],
                ),
              ),
      20.heightBox,
      Row(

        children: [
          10.widthBox,
          Text(
              "Top Course",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              )
          ),
          170.widthBox,
          Text(
              "Lihat Semua",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
              )
          ),
          ]),
              20.heightBox,
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    30.widthBox,
                    Container(
                      width: 192,
                      height: 209,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 192,
                            height: 138,
                            decoration: ShapeDecoration(
                              image: DecorationImage(
                                image: AssetImage("images/bb.png"),
                                fit: BoxFit.fill,
                              ),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                            ),
                          ),
                          Text(
                            '3 Paket Soal Try Out SMA IPA ',
                            style: TextStyle(
                              color: Color(0xFF444444),
                              fontSize: 12,
                              fontFamily: 'Nunito',
                              fontWeight: FontWeight.w600,
                              height: 0,
                            ),
                          ),
                          10.heightBox,
                          Row(
                            children: [
                              Text(
                                'Rp 350.000',
                                style: TextStyle(
                                  color: Color(0xFFF45F5F),
                                  fontSize: 10,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w700,
                                  decoration: TextDecoration.lineThrough,
                                  height: 0,
                                ),
                              ),
                              20.widthBox,
                              Text(
                                'Rp 250.000',
                                style: TextStyle(
                                  color: Color(0xFF263238),
                                  fontSize: 10,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w700,
                                  height: 0,
                                ),
                              ),

                            ],
                          ),
                           10.heightBox,
                           Row(
                             children: [
                               Image.asset('images/group.png',width: 13,height: 13,),
                               Image.asset('images/group.png',width: 13,height: 13,),
                               Image.asset('images/group.png',width: 13,height: 13,),
                               Image.asset('images/group.png',width: 13,height: 13,),
                               Image.asset('images/group.png',width: 13,height: 13,),
                               10.widthBox,
                               Text(
                                   "(2,103)",
                                   style: TextStyle(
                                     fontSize: 10,
                                     fontWeight: FontWeight.w400,
                                   )
                               ),
                               45.widthBox,
                               Container(
                                 width: 35,
                                 height: 20,
                                 decoration: ShapeDecoration(
                                   color: Color(0xFF4E7B79),
                                   shape: RoundedRectangleBorder(
                                     borderRadius: BorderRadius.only(bottomRight: Radius.circular(5)),
                                   ),
                                 ),
                                 child: Image.asset('images/mm.png',width: 13,height: 13,),
                               ),
                             ],
                           )

                        ],
                      ),
                    ),
                    30.widthBox,
                    Container(
                      width: 192,
                      height: 209,
                      clipBehavior: Clip.antiAlias,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 192,
                            height: 138,
                            decoration: ShapeDecoration(
                              image: DecorationImage(
                                image: AssetImage("images/bb.png"),
                                fit: BoxFit.fill,
                              ),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                            ),
                          ),
                          Text(
                            '3 Paket Soal Try Out SMA IPA ',
                            style: TextStyle(
                              color: Color(0xFF444444),
                              fontSize: 12,
                              fontFamily: 'Nunito',
                              fontWeight: FontWeight.w600,
                              height: 0,
                            ),
                          ),
                          10.heightBox,
                          Row(
                            children: [
                              Text(
                                'Rp 350.000',
                                style: TextStyle(
                                  color: Color(0xFFF45F5F),
                                  fontSize: 10,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w700,
                                  decoration: TextDecoration.lineThrough,
                                  height: 0,
                                ),
                              ),
                              20.widthBox,
                              Text(
                                'Rp 250.000',
                                style: TextStyle(
                                  color: Color(0xFF263238),
                                  fontSize: 10,
                                  fontFamily: 'Nunito',
                                  fontWeight: FontWeight.w700,
                                  height: 0,
                                ),
                              ),

                            ],
                          ),
                          10.heightBox,
                          Row(
                            children: [
                              Image.asset('images/group.png',width: 13,height: 13,),
                              Image.asset('images/group.png',width: 13,height: 13,),
                              Image.asset('images/group.png',width: 13,height: 13,),
                              Image.asset('images/group.png',width: 13,height: 13,),
                              Image.asset('images/group.png',width: 13,height: 13,),
                              10.widthBox,
                              Text(
                                  "(2,103)",
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w400,
                                  )
                              ),
                              45.widthBox,
                              Container(
                                width: 35,
                                height: 20,
                                decoration: ShapeDecoration(
                                  color: Color(0xFF4E7B79),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(bottomRight: Radius.circular(5)),
                                  ),
                                ),
                                child: Image.asset('images/mm.png',width: 13,height: 13,),
                              ),
                            ],
                          )

                        ],
                      ),
                    ),
                    30.widthBox,
                  ],
                ),
              )
                ],
              ),
            ],
          ),
        ),
      ),


    );
  }
}
