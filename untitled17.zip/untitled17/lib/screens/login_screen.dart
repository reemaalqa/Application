import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:websafe_svg/websafe_svg.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: InkWell(child: Icon(Icons.arrow_back),onTap: (){
          Navigator.pop(context);
        },),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: SafeArea(

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
    Center(
    child: Stack(

    children: <Widget>[

        Column(
          children: [

            Container(
              margin: EdgeInsets.all(20),
              width: 250,
              height: 240,
              decoration: BoxDecoration(
                color: Colors.transparent,
                image: DecorationImage(

                  image: AssetImage('images/image.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
        ]
    ),
        )
  ]
    ),
          5.heightBox,
          Container(
            margin: EdgeInsets.only(left: 40),
            child: Text(
                "Welcome Back!",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w500,
                )
            ),
          ),
          5.heightBox,
          Container(
            margin: EdgeInsets.only(left: 43),
            child: Text(
              "Enter the email and password that has been \n You register it in advance.",
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w400,
            )
          )
          ),
              20.heightBox,
          Center(
            child: Container(
              width: 320,
              height: 56,

              child: TextField(

                decoration: InputDecoration(
                  hintText: 'Email',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                  ),
                ),
              ),
            ),
          ),
          10.heightBox,
          Center(
            child: Container(
              width: 320,
              height: 56,

              child: TextField(

                decoration: InputDecoration(
                  hintText: 'Password',
                  suffixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                  ),
                ),
              ),
            ),
          ),
5.heightBox,
          Container(

            alignment: Alignment.bottomRight,
            margin: EdgeInsets.only(right: 40),
            child: Text(
                "Forgot Password?",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                )
            )
          ),
          20.heightBox,
          InkWell(
            child: Center(
              child: Container(
                width: 320,
                height: 63,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(17),

                  color: Color(0xffff5978), // هذا هو لون الحدود

                ),
                child: Center(
                  child: Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
          10.heightBox,
            Center(
              child: Align(
                alignment: Alignment.center,
                child: Text(

                  "By logging in or registering, you agree to our Terms of Service and \n                                                  Privacy Policy",
                style: TextStyle(
                                fontSize: 9,
                  fontWeight: FontWeight.w400,
                )
        ),
              ),
            ),
          10.heightBox,
          Center(
            child: Text(
                "Or sign in with",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                )
            ),
          ),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 146,
                height: 47,
                decoration:     BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(5)
                ),
                child: WebsafeSvg.asset('images/n.svg'),
              ),
              Container(
                width: 146,
                height: 47,
                decoration:     BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(5)
                ),
                child: WebsafeSvg.asset('images/e.svg'),
              ),

            ],
          ),
          10.heightBox,
          Center(
            child: Text(
                "Don't have an account yet? Click Here",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                )
            ),
          ),
          10.heightBox,
        ]
    )
    ),
      )
    );
  }
}
