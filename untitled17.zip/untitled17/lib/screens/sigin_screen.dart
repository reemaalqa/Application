import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

import 'home.dart';
import 'home_screen.dart';

class SinginScreen extends StatelessWidget {
  const SinginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        appBar: AppBar(
          leading: InkWell(child: Icon(Icons.arrow_back),onTap: (){
            Navigator.pop(context);
          },),
        ),
        body: Center(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [

                Text(
                    "Create an account",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w500,
                    )
                ),
                15.heightBox,
                Text(
                    "Let’s us know what your name, \n   email, and your password",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    )
                ),
                20.heightBox,
                Center(
                  child: Container(
                    width: 320,
                    height: 56,
                    child: TextField(
                      style: TextStyle(color: Colors.black), // هذا يجعل النص أسود
                      decoration: InputDecoration(
                        fillColor: Colors.white, // هذا يجعل خلفية حقل الإدخال بيضاء
                        filled: true, // هذا مطلوب لتطبيق fillColor
                        hintText: 'First Name',
                        labelText: 'First Name',
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(color: Colors.black,backgroundColor: Colors.white,fontSize: 16),

                        hintStyle: TextStyle(color: Colors.black), // هذا يجعل النص الفارغ أسود
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                        ),
                      ),
                    ),
                  ),
                ),

                20.heightBox,
                Center(
                  child: Container(
                    width: 320,
                    height: 56,
                    child: TextField(
                      style: TextStyle(color: Colors.black), // هذا يجعل النص أسود
                      decoration: InputDecoration(
                        fillColor: Colors.white, // هذا يجعل خلفية حقل الإدخال بيضاء
                        filled: true, // هذا مطلوب لتطبيق fillColor
                        hintText: 'Last Nmae',
                        labelText: 'Last Name',
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(color: Colors.black,backgroundColor: Colors.white,fontSize: 16),
                        hintStyle: TextStyle(color: Colors.black), // هذا يجعل النص الفارغ أسود
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                        ),
                      ),
                    ),
                  ),
                ),
                20.heightBox,
                Center(
                  child: Container(
                    width: 320,
                    height: 56,
                    child: TextField(
                      style: TextStyle(color: Colors.black), // هذا يجعل النص أسود
                      decoration: InputDecoration(
                        fillColor: Colors.white,
                        labelText: 'Email',
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(color: Colors.black,backgroundColor: Colors.white,fontSize: 16),
                        filled: true, // هذا مطلوب لتطبيق fillColor
                        hintText: 'Email',
                        hintStyle: TextStyle(color: Colors.black), // هذا يجعل النص الفارغ أسود
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                        ),
                      ),
                    ),
                  ),
                ),
                20.heightBox,
                Center(
                  child: Container(
                    width: 320,
                    height: 56,
                    child: TextField(
                      style: TextStyle(color: Colors.black), // هذا يجعل النص أسود
                      decoration: InputDecoration(
                        fillColor: Colors.white, // هذا يجعل خلفية حقل الإدخال بيضاء
                        filled: true, // هذا مطلوب لتطبيق fillColor
                        hintText: 'Password',
                        labelText: 'Password',
                        suffixIcon: Icon(Icons.visibility_off),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(color: Colors.black,backgroundColor: Colors.white,fontSize: 16),
                        hintStyle: TextStyle(color: Colors.black), // هذا يجعل النص الفارغ أسود
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                        ),
                      ),
                    ),
                  ),
                ),
                20.heightBox,
                Center(
                  child: Container(
                    width: 320,
                    height: 56,
                    child: TextField(
                      style: TextStyle(color: Colors.black), // هذا يجعل النص أسود
                      decoration: InputDecoration(
                        fillColor: Colors.white, // هذا يجعل خلفية حقل الإدخال بيضاء
                        filled: true, // هذا مطلوب لتطبيق fillColor
                        hintText: 'Confirem Password',
                        labelText: 'Confirem Password',
                        suffixIcon: Icon(Icons.visibility_off),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(color: Colors.black,backgroundColor: Colors.white,fontSize: 16),
                        hintStyle: TextStyle(color: Colors.black), // هذا يجعل النص الفارغ أسود
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(color: Colors.brown, width: 1.0), // هذا هو اللون البني للحدود
                        ),
                      ),
                    ),
                  ),
                ),
                40.heightBox,
                InkWell(
                  onTap: (){
                    Navigator.push(context,MaterialPageRoute(builder: (context)=>Home()));
                  },
                  child: Container(
                    width: 320,
                    height: 63,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(17),

                      color: Color(0xffff5978), // هذا هو لون الحدود

                    ),
                    child: Center(
                      child: Text(
                        "Register",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
