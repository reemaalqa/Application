
import 'package:flutter/material.dart';
import 'package:untitled17/screens/splesh_screenone.dart';
import 'package:velocity_x/velocity_x.dart';
class SpleshScreen extends StatefulWidget {
  const SpleshScreen({super.key});

  @override
  State<SpleshScreen> createState() => _SpleshScreenState();
}

class _SpleshScreenState extends State<SpleshScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Spacer(),
            Row(

              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Card(
                  color: Colors.white,
                  shadowColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  child: Container(
                    padding: EdgeInsets.all(50.0),
                    child: Column(
                      children: <Widget>[
                        Icon(Icons.school,color: Color(0xFFFF5978),weight: 50,),
                        10.heightBox,
                        'Student'.text.size(16).make(),
                      ],
                    ),
                  ),
                ),
                Card(
                  color: Colors.white,
                  shadowColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  child: Container(
                    padding: EdgeInsets.all(50.0),
                    child: Column(
                      children: <Widget>[
                        Icon(Icons.person,color: Color(0xFFFF5978)),
                        Text('Teacher'),
                      ],
                    ),
                  ),
                ),

              ],
            ),
            Spacer(),
            Spacer(),
            InkWell(
              onTap: (){
                Navigator.push(context,MaterialPageRoute(builder: (context)=>SpleshScreenOne()));
              },
              child: Container(
                width: double.infinity ,
                alignment: Alignment.center,
                height: 63,
                padding: EdgeInsets.all(15),
                margin: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Color(0xFFFF5978),
                    borderRadius: BorderRadius.all(Radius.circular(12))
                ),
                child: Text('Next',style: TextStyle(color: Colors.white,fontSize: 20),),

              ),
            ),
          ],
        ),
      ),



    );
  }
}
