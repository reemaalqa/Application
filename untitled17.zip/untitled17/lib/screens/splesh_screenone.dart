import 'package:flutter/material.dart';
import 'package:untitled17/screens/login_screen.dart';
import 'package:untitled17/screens/sigin_screen.dart';
import 'package:velocity_x/velocity_x.dart';

class SpleshScreenOne extends StatelessWidget {
  const SpleshScreenOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(
       leading: InkWell(child: Icon(Icons.arrow_back),onTap: (){
         Navigator.pop(context);
       },),
     ),
      body: SafeArea(

        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Stack(

                    children: <Widget>[
20.heightBox,
                      Column(
                        children: [
                          30.heightBox,
                          Container(
                            margin: EdgeInsets.all(20),
                            width: 259,
                            height: 259,
                            decoration: BoxDecoration(
                              image: DecorationImage(

                                image: AssetImage('images/ellipse47.png'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ],
                      ),
    Center(
      child: Column(
      children: [
            30.heightBox,
                    Container(
                        width: 300,
                        height: 279,

                        decoration: BoxDecoration(
                          image: DecorationImage(
                                image: AssetImage('images/group53.png',),
                            fit: BoxFit.fill,

                          ),
                        ),
                      ),
      ]),
    )

                    ],
                  ),
                ),
              ],
            ),
            20.heightBox,
            "The Best E - Learning".text.size(20).bold.make(),
            20.heightBox,
            Container(
                width: 76,
                height: 3,
                decoration:     BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Color(0xff4e7b79))
            ),
            20.heightBox,
            Text(
                "Provides a lot of material, questions and \n discussions that are easy to understand ",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                )
            ),
            30.heightBox,
        InkWell(
          onTap: (){
            Navigator.push(context,MaterialPageRoute(builder: (context)=>LoginScreen()));
          },
          child: Container(
            width: 320,
            height: 63,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: Color(0xff4e7b79), // هذا هو لون الحدود
                width: 3, // هذا هو عرض الحدود
              ),
            ),
            child: Center(
              child: Text(
                "Login",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff4e7b79),
                ),
              ),
            ),
          ),
        ),
10.heightBox,

            InkWell(
              onTap: (){
                Navigator.push(context,MaterialPageRoute(builder: (context)=>SinginScreen()));
              },
              child: Container(
                width: 320,
                height: 63,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(17),

                  color: Color(0xffff5978), // هذا هو لون الحدود

                ),
                child: Center(
                  child: Text(
                    "Register",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

    );
  }
}
